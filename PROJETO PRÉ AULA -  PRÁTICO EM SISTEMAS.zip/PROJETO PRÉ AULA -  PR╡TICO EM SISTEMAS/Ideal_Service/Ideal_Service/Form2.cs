﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Ideal_Service
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=root");
        private string strMySQL;

        private void ConsultarProduto()
        {
            strMySQL = "Select * From ideal_service.produtos where ProdutoID='"+txtConsulta.Text+"'";
            MySqlDataAdapter comando = new MySqlDataAdapter(strMySQL, con);

            try
            {
                con.Open();
                DataSet ds = new DataSet();
                comando.Fill(ds, "ideal_service.produtos");
                int cont = ds.Tables["ideal_service.produtos"].Rows.Count;

                if(cont == 0)
                {
                    MessageBox.Show("PRODUTRO NÃO CADASTRADO! TENTE NOVAMENTE!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtConsulta.Clear();
                    txtConsulta.Focus();
                }

                else if(cont > 0)
                {
                    byte[] data = new Byte[0];
                    data = (Byte[])(ds.Tables["ideal_service.produtos"].Rows[cont - 1]["Foto"]);
                    MemoryStream stream = new MemoryStream(data);
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    pictureBox1.Image = Image.FromStream(stream);
                    txtCod.Text = Convert.ToString(ds.Tables["ideal_service.produtos"].Rows[cont - 1]["ProdutoID"]);
                    txtNome.Text = Convert.ToString(ds.Tables["ideal_service.produtos"].Rows[cont - 1]["Nome"]);
                    txtQuant.Text = Convert.ToString(ds.Tables["ideal_service.produtos"].Rows[cont - 1]["Quantidade"]);
                    txtValor.Text = Convert.ToString(ds.Tables["ideal_service.produtos"].Rows[cont - 1]["Preco"]);
                }
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally
            {
                con.Close();
            }
        }

        private void AlterarProduto()
        {
            strMySQL = "update ideal_service.produtos set ProdutoID=@ProdutoID, Nome=@Nome, Preco=@Preco, Quantidade=@Quantidade, Foto=@Foto where ProdutoID='" +txtCod.Text+ "'";
            MySqlCommand comando = new MySqlCommand(strMySQL, con);

            comando.Parameters.AddWithValue("@ProdutoID", txtCod.Text);
            comando.Parameters.AddWithValue("@Nome", txtNome.Text);
            comando.Parameters.Add("@Preco", MySqlDbType.Float).Value = txtValor.Text;
            comando.Parameters.AddWithValue("@Quantidade", txtQuant.Text);
            comando.Parameters.AddWithValue("@Foto", ConverterParaBitArray());

            try
            {
                con.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("DADOS SALVOS COM SUCESSO!", "MENSAGEM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
            }
        }

        private void ExcluirProduto()
        {
            strMySQL = "delete from ideal.service.produtos where ProdutoID='" + txtCod.Text + "'";  
            MySqlCommand comando = new MySqlCommand(strMySQL, con);

            try
            {
                con.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("ITEM EXCLUÍDO COM SUCESSO!", "MENSAGEM", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
            }
        }

        private byte[] ConverterParaBitArray()
        {
            MemoryStream stream = new MemoryStream();
            byte[] bArray;

            if (pictureBox1.Image == null)
            {
                stream = null;
                bArray = new byte[stream.Length];
            }

            else if (pictureBox1.Image != null)
            {
                pictureBox1.Image.Save(stream, ImageFormat.Png);
                stream.Seek(0, SeekOrigin.Begin);
            }

            bArray = new byte[stream.Length];
            stream.Read(bArray, 0, Convert.ToInt32(stream.Length));
            return bArray;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            txtConsulta.Focus();
        }

        private void txtConsulta_KeyUp(object sender, KeyEventArgs e)
        {
            ConsultarProduto();
            txtConsulta.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                OpenFileDialog abrir = new OpenFileDialog();
                abrir.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
                abrir.Filter = "Image Files (*.bmp, *.jpg, *.jpeg)| *.bmp; *.jpg; *.png; *.jpeg";
                abrir.Multiselect = false;

                if (abrir.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    pictureBox1.Image = new Bitmap(abrir.FileName);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AlterarProduto();
            txtCod.Clear();
            txtNome.Clear();
            txtQuant.Clear();
            txtValor.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ExcluirProduto();
            txtCod.Clear();
            txtNome.Clear();
            txtQuant.Clear();
            txtValor.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
            Form1 f1 = new Form1();
            f1.Visible = true;
        }
    }
}
