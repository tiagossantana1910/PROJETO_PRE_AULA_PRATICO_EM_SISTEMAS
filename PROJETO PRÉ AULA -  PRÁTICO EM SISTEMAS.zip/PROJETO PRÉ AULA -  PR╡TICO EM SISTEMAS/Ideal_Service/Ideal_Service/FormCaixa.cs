﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Drawing.Imaging;

namespace Ideal_Service
{
    public partial class FormCaixa : Form
    {
        public FormCaixa()
        {
            InitializeComponent();
        }

        MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=root");
        private string strMySQL;
        float TotalVenda;
        public static int quant;
        public static float nValor;

        private void GerarCodigoVenda()
        {
            strMySQL = "select max(VendaID) from ideal_service.caixa";

            try
            {
                con.Open();
                MySqlCommand comando = new MySqlCommand(strMySQL, con);

                if(comando.ExecuteScalar() == DBNull.Value)
                {
                    lblCod.Text = "1";
                }

                else
                {
                    Int32 ra = Convert.ToInt32(comando.ExecuteScalar()) + 1;
                    lblCod.Text = ra.ToString();
                }
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            finally
            {
                con.Close();
            }
        }

        private void ConsultarProduto()
        {
            strMySQL = "select * from ideal_service.produtos where ProdutoID='" + txtCod.Text + "'";
            MySqlCommand comando = new MySqlCommand(strMySQL, con);

            try
            {
                con.Open();
                MySqlDataReader dr = comando.ExecuteReader();
                dr.Read();

                if (!dr.HasRows)
                {
                    MessageBox.Show("PRODUTO NÃO ENCONTRADO! EFETUE O CADASTRO", "MENSAGEM", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtCod.Clear();
                    txtCod.Focus();
                }

                else
                {
                    txtNome.Text = dr["Nome"].ToString();
                    int quantidade = int.Parse(dr["Quantidade"].ToString());
                    txtValor.Text = dr["Preco"].ToString();
                    txtQuant.Focus();
                }
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                con.Close();
            }
        }

        private void GravarVenda()
        {
            strMySQL = "insert into ideal_service.caixa(VendaID, ValorTotal) values (@VendaID, @ValorTotal)";
            MySqlCommand comando = new MySqlCommand(strMySQL, con);

            comando.Parameters.AddWithValue("@VendaID", Convert.ToInt32(lblCod.Text));
            comando.Parameters.AddWithValue("@ValorTotal", Convert.ToDecimal(txtTotal2.Text));

            try
            {
                con.Open();
                comando.ExecuteNonQuery();
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Inserir();
                dataGridView1.Rows.Clear();
                TotalVenda = 0;
                txtTotal2.Text = "0";
                txtCod.Focus();
                con.Close();
            }
        }

        private void Inserir()
        {
            strMySQL = "insert into ideal_service.itemvenda(VendaID, ProdutoID, Quantidade, ValorTotal) values(@VendaID, @ProdutoID, @Quantidade, @ValorTotal)";
            MySqlCommand comando = new MySqlCommand(strMySQL, con);

            try
            {
                if(con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                for(int i = 0; i<dataGridView1.Rows.Count - 1; i++)
                {
                    comando.Parameters.Clear();
                    comando.Parameters.AddWithValue("@VendaID", lblCod.Text);
                    comando.Parameters.AddWithValue("@ProdutoID", dataGridView1.Rows[i].Cells[0].Value);
                    comando.Parameters.AddWithValue("@Quantidade", dataGridView1.Rows[i].Cells[3].Value);
                    comando.Parameters.AddWithValue("@ValorTotal", float.Parse(dataGridView1.Rows[i].Cells[4].Value.ToString()));

                    comando.ExecuteNonQuery();
                }
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void Limpar()
        {
            txtCod.Clear();
            txtNome.Clear();
            txtQuant.Clear();
            txtTotal1.Clear();
            txtValor.Clear();
        }

        private void NomearDataGrid()
        {
            dataGridView1.ColumnCount = 5;
            dataGridView1.Columns[0].Name = "Código";
            dataGridView1.Columns[1].Name = "Produto";
            dataGridView1.Columns[1].Width = 267;
            dataGridView1.Columns[2].Name = "Valor Unitário";
            dataGridView1.Columns[3].Name = "Quantidade";
            dataGridView1.Columns[4].Name = "Total";
        }

        private void ConsultarQuantidade()
        {
            strMySQL = "select Quantidade from ideal_service.produtos where ProdutoID='" + txtCod.Text + "'";
            MySqlCommand comando = new MySqlCommand(strMySQL, con);

            try
            {
                con.Open();
                MySqlDataReader dr = comando.ExecuteReader();

                while (dr.Read())
                {
                    if((int.Parse(dr["Quantidade"].ToString()) < int.Parse(txtQuant.Text) || (int.Parse(dr["Quantidade"].ToString()) <= 0)))
                    {
                        MessageBox.Show("ESTOQUE DE PRODUTO ESGOTADO, NÃO É POSSÍVEL ADICIONAR ESTE ITEM", "MENSAGEM", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txtQuant.Clear();
                    }
                }

                quant = int.Parse(dr["Quantidade"].ToString());

                if(quant <= 0)
                {
                    txtQuant.Clear();
                }

                txtQuant.Focus();
            }

            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                Close();
            }
        }

        private void AlterarQuantidade()
        {
            int quantidade = 0;
            quantidade = quant - int.Parse(txtQuant.Text);

            if(quantidade <= 0)
            {
                quantidade = 0;
            }

            strMySQL = "update ideal_service.produtos set Quantidade=@Quantidade where ProdutoID='" + txtCod.Text + "'";
            MySqlCommand comando = new MySqlCommand(strMySQL, con);

            comando.Parameters.AddWithValue("@Quantidade", quantidade);

            try
            {
                con.Close();
                con.Open();
                comando.ExecuteNonQuery();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            finally
            {
                con.Close();
            }
        }

        private void FormCaixa_Load(object sender, EventArgs e)
        {
            GerarCodigoVenda();
            NomearDataGrid();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtQuant_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txtCod_Validating(object sender, CancelEventArgs e)
        {
            if(txtCod.Text != string.Empty)
            {
                ConsultarProduto();
            }

            else
            {
                txtCod.Focus();
            }
        }

        private void txtCod_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtQuant_Validating(object sender, CancelEventArgs e)
        {

            ConsultarQuantidade();

            if(txtQuant.Text != string.Empty)
            {
                txtTotal1.Text = (float.Parse(txtValor.Text) * float.Parse(txtQuant.Text)).ToString();
                button1.Focus();
                AlterarQuantidade();
            }

            else
            {
                MessageBox.Show("DIGITE A QUANTIDADE", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtQuant.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add(txtCod.Text, txtNome.Text, txtValor.Text, txtQuant.Text, txtTotal1.Text);
            TotalVenda += float.Parse(txtTotal1.Text);
            txtTotal2.Text = TotalVenda.ToString();

            Limpar();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            GravarVenda();
            GerarCodigoVenda();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            nValor = float.Parse(dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString());
            dataGridView1.Rows.RemoveAt(e.RowIndex);
            TotalVenda -= nValor;
            txtTotal2.Text = TotalVenda.ToString();
        }

        void FecharForm(KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Escape){
                Close();
            }
        }

        void PularControles(KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                SendKeys.Send("{TAB}");
            }
        }

        void FinalizarCompra(KeyEventArgs e)
        {
            if(e.KeyCode == Keys.F2)
            {
                button2.PerformClick();
            }
        }

        private void FormCaixa_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Escape)
            {
                FecharForm(e);
            }

            else if (e.KeyCode == Keys.Enter)
            {
                PularControles(e);
            }

            else if(e.KeyCode == Keys.F2)
            {
                FinalizarCompra(e);
            }
        }
    }
}
